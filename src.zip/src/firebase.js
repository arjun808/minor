
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
import 'firebase/compat/storage';

const firebaseConfig = {
  apiKey: "AIzaSyBnEkMtGhp_qCl1rR6f6ITBqquuRJlfyzU",
  authDomain: "clone-of-disney.firebaseapp.com",
  projectId: "clone-of-disney",
  storageBucket: "clone-of-disney.appspot.com",
  messagingSenderId: "414718649140",
  appId: "1:414718649140:web:4d679307cb8097d74cbb61",
  measurementId: "G-ECQD4S7TKJ"
};

const firebaseApp = firebase.initializeApp(firebaseConfig);
const db = firebaseApp.firestore();
const auth = firebase.auth();
const provider = new firebase.auth.GoogleAuthProvider();
const storage = firebase.storage();

export { auth, provider, storage };
export default db;
